**Start to train your own tabularq-agent**

Follow the instructions and then you can reply the same performance as below.

**gridworld**

>python main.py --scenario gridworld --algo tabularq --reload_config

[comment]: <> (![image]&#40;../../assets/grid_tabular.png&#41;)

[comment]: <> (<img src="https://github.com/jidiai/ai_lib/raw/master/examples/assets/grid_tabularq.png" alt="grid_tabularq" width="400" height="300" align="middle" />)

