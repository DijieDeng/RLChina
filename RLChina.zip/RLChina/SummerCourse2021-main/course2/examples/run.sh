python main.py --scenario gridworld --algo sarsa --reload_config &
python main.py --scenario gridworld --algo tabularq --reload_config &
python main.py --scenario cliffwalking --algo sarsa --reload_config &
python main.py --scenario cliffwalking --algo tabularq --reload_config
