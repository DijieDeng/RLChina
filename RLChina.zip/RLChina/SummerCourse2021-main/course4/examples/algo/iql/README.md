**Start to train your own iql-agent**

Follow the instructions and then you can reply the same performance as below.

**classic_CartPole-v0**

>python main.py --scenario classic_CartPole-v0 --algo dqn --reload_config

![image](../assets/dqn_cartpole.png)

[comment]: <> (**classic_MountainCar-v0**)

[comment]: <> (>python main.py --scenario classic_MountainCar-v0 --algo dqn --reload_config)

[comment]: <> (![image]&#40;https://github.com/jidiai/ai_lib/raw/master/examples/assets/dqn_mountaincar.png&#41;)