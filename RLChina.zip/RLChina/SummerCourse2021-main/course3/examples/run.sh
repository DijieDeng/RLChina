python main.py --scenario classic_CartPole-v0 --algo dqn --reload_config &
python main.py --scenario classic_CartPole-v0 --algo ddqn --reload_config &
python main.py --scenario classic_CartPole-v0 --algo duelingq --reload_config
