**Start to train your own dqn-agent**

Follow the instructions and then you can reply the same performance as below.

**classic_CartPole-v0**

>python main.py --scenario classic_CartPole-v0 --algo ddqn --reload_config

[comment]: <> (![image]&#40;https://github.com/jidiai/ai_lib/raw/master/examples/assets/ddqn_cartpole.png&#41;)