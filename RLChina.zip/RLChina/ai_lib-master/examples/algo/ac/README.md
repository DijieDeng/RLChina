**Start to train your own ac-agent**

Follow the instructions and then you can reply the same performance as below.

>cd ../examples

**classic_CartPole-v0**

>python main.py --scenario classic_CartPole-v0 --algo ac --reload_config

![image](https://github.com/jidiai/ai_lib/raw/master/examples/assets/ac_cartpole.png)
