**Start to train your own tabularq-agent**

Follow the instructions and then you can reply the same performance as below.

>cd ../examples

**gridworld**

>python main.py --scenario gridworld --algo tabularq --reload_config

<img src="https://github.com/jidiai/ai_lib/raw/master/examples/assets/grid_tabularq.png" alt="grid_tabularq" width="400" height="300" align="middle" />

![image](https://github.com/jidiai/ai_lib/raw/master/examples/assets/tabularq_gridworld.png)