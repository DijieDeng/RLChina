**Start to train your own duelingq-agent**

Follow the instructions and then you can reply the same performance as below.

>cd ../examples

**classic_CartPole-v0**

>python main.py --scenario classic_CartPole-v0 --algo duelingq --reload_config

![image](https://github.com/jidiai/ai_lib/raw/master/examples/assets/duelingq_cartpole.png)

**classic_MountainCar-v0**

>python main.py --scenario classic_MountainCar-v0 --algo duelingq --reload_config

![image](https://github.com/jidiai/ai_lib/raw/master/examples/assets/duelingq_mountaincar.png)