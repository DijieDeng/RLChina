**Start to train your own td3-agent**

Follow the instructions and then you can reply the same performance as below.

>cd ../examples

**classic_Pendulum-v0**

>python main.py --scenario classic_Pendulum-v0 --algo td3 --reload_config

![image](https://github.com/jidiai/ai_lib/raw/master/examples/assets/td3_pendulum.png)

