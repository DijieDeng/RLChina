**Start to train your own sarsa-agent**

Follow the instructions and then you can reply the same performance as below.

>cd ../examples

**gridworld**

>python main.py --scenario gridworld --algo sarsa --reload_config

<img src="https://github.com/jidiai/ai_lib/raw/master/examples/assets/grid_sarsa.png" alt="grid_sarsa" width="400" height="300" align="middle" />

![image](https://github.com/jidiai/ai_lib/raw/master/examples/assets/sarsa_gridworld.png)