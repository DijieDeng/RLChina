**Start to train your own pg-agent**

Follow the instructions and then you can reply the same performance as below.

>cd ../examples

**classic_CartPole-v0**

>python main.py --scenario classic_CartPole-v0 --algo pg --reload_config

![image](https://github.com/jidiai/ai_lib/raw/master/examples/assets/pg_cartpole.png)
