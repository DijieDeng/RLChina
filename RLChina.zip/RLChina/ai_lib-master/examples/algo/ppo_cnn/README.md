**Start to train your own ppo-agent**

Follow the instructions and then you can reply the same performance as below.

>cd ../examples


**MiniWorld-OneRoom-v0**

>python main.py --scenario MiniWorld_OneRoom-v0 --algo ppo_cnn --reload_config

![image](https://github.com/eigebi/ai_lib/blob/master/examples/assets/ppo_MiniWorld_OneRoon_v0.png)
