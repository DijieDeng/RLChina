**Start to train your own maddpg-agents**

Follow the instructions and then you can reply the same performance as below.

>cd ../examples

**ParticleEnv-simple_spread**

>python main.py --scenario ParticleEnv-simple_spread --algo maddpg --reload_config

![image](https://github.com/eigebi/ai_lib/blob/master/examples/assets/maddpg_particleenv_simple_spread.png)