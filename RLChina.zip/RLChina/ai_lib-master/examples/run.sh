python main.py --scenario classic_CartPole-v0 --algo dqn --reload_config &
python main.py --scenario classic_CartPole-v0 --algo ddqn --reload_config &
python main.py --scenario classic_CartPole-v0 --algo duelingq --reload_config &
python main.py --scenario classic_CartPole-v0 --algo pg --reload_config &
python main.py --scenario classic_CartPole-v0 --algo ac --reload_config &
python main.py --scenario classic_CartPole-v0 --algo ppo --reload_config &
python main.py --scenario classic_CartPole-v0 --algo sac --reload_config &
python main.py --scenario classic_Pendulum-v0 --algo td3 --reload_config &
python main.py --scenario classic_CartPole-v0 --algo ddpg --reload_config &
python main.py --scenario classic_MountainCar-v0 --algo dqn --reload_config &
python main.py --scenario classic_MountainCar-v0 --algo ddqn --reload_config &
python main.py --scenario classic_MountainCar-v0 --algo duelingq --reload_config &
python main.py --scenario classic_Pendulum-v0 --algo sac --reload_config &
python main.py --scenario classic_MountainCar-v0 --algo sac --reload_config &
python main.py --scenario gridworld --algo sarsa --reload_config &
python main.py --scenario gridworld --algo tabularq --reload_config

